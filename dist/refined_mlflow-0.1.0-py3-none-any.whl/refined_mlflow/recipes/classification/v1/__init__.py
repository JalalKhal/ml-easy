from recipes.classification.v1.config import ClassificationRecipeConfig as ConfigImpl
from recipes.classification.v1.recipe import ClassificationRecipe as RecipeImpl

__all__ = ['RecipeImpl', 'ConfigImpl']
